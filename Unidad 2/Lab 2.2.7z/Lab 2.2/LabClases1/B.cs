public class B: A
{
	public B()
	{
		nombreInstancia = "Instancia de B"
	}
	public string M4()
    {
		return "Metodo del hijo Invocado";
    }
}
